"""Unit tests for the examples."""
