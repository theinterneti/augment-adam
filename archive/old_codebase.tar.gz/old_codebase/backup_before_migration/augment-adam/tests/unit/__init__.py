"""Unit tests for the Augment Adam package."""
