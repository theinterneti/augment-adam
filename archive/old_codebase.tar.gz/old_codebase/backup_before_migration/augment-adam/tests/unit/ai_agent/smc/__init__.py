"""Unit tests for the SMC module."""
