"""Unit tests for the agent coordination module."""
