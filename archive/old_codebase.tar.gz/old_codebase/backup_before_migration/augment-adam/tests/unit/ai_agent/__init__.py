"""Unit tests for the AI Agent module."""
