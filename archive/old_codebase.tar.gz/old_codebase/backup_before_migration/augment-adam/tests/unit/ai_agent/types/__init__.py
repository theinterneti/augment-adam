"""Unit tests for the agent types."""
