"""Performance tests for the agent coordination module."""
