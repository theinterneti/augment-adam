"""Compatibility tests for the agent coordination module."""
