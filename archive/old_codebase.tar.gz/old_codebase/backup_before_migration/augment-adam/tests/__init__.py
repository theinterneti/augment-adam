"""Tests for the Augment Adam package."""
