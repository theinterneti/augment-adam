"""Integration tests for the Augment Adam package."""
