"""Integration tests for the agent coordination module."""
