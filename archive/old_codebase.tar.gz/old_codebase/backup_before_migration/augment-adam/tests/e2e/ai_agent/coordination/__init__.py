"""End-to-end tests for the agent coordination module."""
