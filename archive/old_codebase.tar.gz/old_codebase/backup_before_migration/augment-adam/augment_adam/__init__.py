"""Augment Adam: An intelligent assistant with advanced memory capabilities.

Augment Adam is an intelligent assistant that uses advanced memory systems
to provide more contextual and personalized responses.

Version: 0.1.0
Created: 2025-04-25
"""

__version__ = "0.1.0"
__author__ = "Augment Adam Team"