"""Server module for Augment Adam.

This module provides a FastAPI server for Augment Adam.

Version: 0.1.0
Created: 2025-04-29
"""

from augment_adam.server.api import start_server
